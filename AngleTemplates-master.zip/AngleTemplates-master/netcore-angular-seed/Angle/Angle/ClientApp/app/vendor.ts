/* This file is mainly used for importing third party scripts */

// import 'jquery';
import './core/wrapper/wrapper.js';
import "popper.js";
